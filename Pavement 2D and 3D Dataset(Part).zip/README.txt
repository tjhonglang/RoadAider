2D and 3D images are taken at the same location
2D: 1024*512 
3D: 1024*512

More information, please contact honglang@tongji.edu.cn